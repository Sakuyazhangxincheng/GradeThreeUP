#include "SUV.h"

SUV::SUV()
{
	color = 1;
}

SUV::~SUV()
{
	cout << "SUV���ͷ�" << endl;
}

void SUV::show()
{
	cout << "this is a SUV" << endl;
}
