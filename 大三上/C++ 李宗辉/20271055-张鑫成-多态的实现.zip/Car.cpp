#include "Car.h"

Car::~Car()
{
	cout << "car is released" << endl;
}
