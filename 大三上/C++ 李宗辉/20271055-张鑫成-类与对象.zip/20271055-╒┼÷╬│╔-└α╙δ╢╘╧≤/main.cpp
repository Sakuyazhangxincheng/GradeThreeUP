#include<iostream>
#include "Book.h"
using namespace std;
int main()
{
	Book book("ABC",3);
	book.show();
}