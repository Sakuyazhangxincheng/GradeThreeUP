using namespace std;
class List {
public:
	int field[5] = {};
	List();
	int addItem(int item);
	int isEmpty();
	int isFull();
	void show();
};
